#include<stdio.h>
int main()
{
 int v1=10,v2=20;
printf("v1=%d  v2=%d",v1,v2);
printf("enter int for v2:");
scanf("%d",&v2);
printf("enter int for v1:");
scanf("%d",&v1);
printf("v1=%d  v2=%d",v1,v2);
}
