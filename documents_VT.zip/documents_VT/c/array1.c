#include<stdio.h>
int main()
{
//char *p=calloc(100,1);
//p="welcome";
//printf(pranali);
char c='d';
putchar(c);
}
