#include<stdio.h>
int main()
{
	int n,m,i,j,k,p,t=0;
	printf("enter n:");
	scanf("%d",&n);
	p=m=n;k=1;
	for(i=-(n-1),k=0;i<=(n-1);i++,printf("\n"))
	{	
		
		for(j=-(n-1);j<=(n-1);j++)
		{
			int A,B;
			A=i;
			if(A<0)
			A=-A;
			B=j;
			if(B<0)
			B=-B;
			if(A==0 && B==0)
				printf("1 ");
				
			else if(A==(n-1) || B==(n-1))
				printf("%d ",n);
			else if(A==(n-2) || B==(n-2))
				printf("%d ",n-1);
			else if(A==(n-3) || B==(n-3))
				printf("%d ",n-2);
			else if(A==(n-4) || B==(n-4))
				printf("%d ",n-3);
		}
	
	}
}
