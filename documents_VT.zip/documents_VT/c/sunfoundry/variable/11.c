        #include <stdio.h>

        int main()

        {

            int a = 10, b = 5, c = 3;

            b != !a;

            c = !!a;

            printf("%d\t%d", b, c);

        }
