#include<stdio.h>
int main()
{
char *str="pranali\0" "dhudum";
printf("%s",str);
}
