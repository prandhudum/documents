        #include <stdio.h>

        int const print()

        {

            printf("Sanfoundry.com");

            return 0;

        }

        void main()

        {

           int a= print();
		printf("%d",a);

        }
