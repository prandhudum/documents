        #include <stdio.h>

        void main()

        {

            int y = 3;

            int x = 5 % 2 * 3 / 2;

            printf("Value of x is %d", x);

        }
