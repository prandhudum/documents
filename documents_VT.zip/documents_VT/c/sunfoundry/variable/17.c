#include<stdio.h>
int main()
{
        unsigned int x = -5;

        printf("%d", x);
}
