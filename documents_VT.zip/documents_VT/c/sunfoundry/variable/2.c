        #include  <stdio.h>

        int main()

        {

           signed char chr;

           chr = 130;

           printf("%d\n", chr);

           return 0;

        }
