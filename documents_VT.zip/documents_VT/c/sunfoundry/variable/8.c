#include <stdio.h>

        int main()

        {

            int i = -3;

            int l = i / 2;

            int k = i % 2;

            printf("%d %d\n", l, k);

            return 0;

        }
