        #include <stdio.h>

        #define a 10

        int main()

        {

            const  int  a = 5;

            printf("a = %d\n", a);

        }
