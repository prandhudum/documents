        #include <stdio.h>

        int main()

        {

            int k;

            {

                int k;

                for (k = 0; k < 10; k++);

            }

        }
