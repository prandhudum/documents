#include<stdio.h>
#include<stdlib.h>
static int cnt;
char *getstring()
{
	char *p=NULL;
	int i=0;
	do{
		p=realloc(p,i+1);
		p[i]=getchar();
	}while(p[i++]!=10);
	p[i-1]=0;
	return p;
}
char**input(char **string)
{
	string=realloc(string,(cnt+1)*sizeof(*string));
	printf("enter name");
	
	string[cnt]=getstring();
	cnt++;
	return string;
                                                           
}
int main()
{
	char **string=NULL;
	int i=0;
	string=input(string);
	string=input(string);
	for(i=0;i<cnt;i++)
	printf("%s\n",string[i]);

}
