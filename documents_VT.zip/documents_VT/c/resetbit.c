#include<stdio.h>
int main()
{
	int data,i,k;
	printf("enter data:");
	scanf("%d",&data);
	for(i=0;i<sizeof(data);i++)
	{	k=((data>>i)&1);
	
		if(k==1)
		{
		data&=~((1<<i));
		break;
		}
	}
	printf("%d",data);
}
