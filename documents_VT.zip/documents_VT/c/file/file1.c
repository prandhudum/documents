#include<stdio.h>
#include<string.h>
void strrev1(char *p)
{
	int i,j;
char temp;
	for(i=0,j=strlen(p)-1;i<j;i++,j--)
	{
	//	char temp;
		temp=*(p+i);
		*(p+i)=*(p+j);
		*(p+j)=temp;
	}
}
int main()
{
	char p[]="hello";
	printf("%s",p);
	strrev1(p);
	printf("%s",p);
}
