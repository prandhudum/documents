#include <stdio.h>
int main()
{
    int dec, qut, rem;
    int i, j = 0;
    char hexadecimal[100];
    printf("Enter decimal number: ");
    scanf("%d", &dec);
    qut = dec;
    while (qut != 0)
    {
        rem = qut % 16;
        if (rem < 10)
            hexadecimal[j++] = 48 + rem;
        else
            hexadecimal[j++] = 55 + rem;
        qut = qut / 16;
    }

     for (i = j; i >= 0; i--)
           printf("%c", hexadecimal[i]);
    return 0;
}
