#include<stdio.h>
int main()
{
int  p=0x1234,q;
char *cp;
int *ip=&p;
ip=*cp;
printf("%x",*cp);

}
