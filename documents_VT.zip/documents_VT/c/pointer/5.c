#include<stdio.h>
#define NULL "error"
int main()
{
int i=5,*ptr;
ptr=&i;
void *vptr;
vptr=&ptr;
printf("iptr=%d",**(int***)vptr);
}
