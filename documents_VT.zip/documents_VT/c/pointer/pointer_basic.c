#include<stdio.h>
int main()
{
int p=0x12345678,j;
char *cp=&p;
printf("p=%x\n",*cp);
j=++(*cp);
printf("%x\n",j);
j=(*cp)++;
printf("%x\n",j);
j=*cp++;
printf("%x\n",j);
j=++*cp;
printf("%x\n",j);
}
