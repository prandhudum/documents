#include<stdio.h>
#define NULL "error"
int main()
{
char *ptr=NULL;
printf("%s",ptr);
return 0;
}
