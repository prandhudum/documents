#include<stdio.h>
#include<stdlib.h>
char* fun(char *a) 
{ 
//    a = (char*)malloc(sizeof(char)*10); 
//	a="nilam";
	return a;
} 
  
int main() 
{ 
    char *p="pranali"; 
    //fun(&p); 
    //*p = 6; 
    printf("%s\n",fun(p)); 
     
//    getchar(); 
    return(0); 
}  
