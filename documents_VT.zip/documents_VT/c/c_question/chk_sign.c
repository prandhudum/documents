#include<stdio.h>
int main()
{
int data1,data2,bit=31;
scanf("%d %d",&data1,&data2);
if(((data1>>bit)&1)!=((data2>>bit)&1))
printf("true");
else
printf("false");

}
