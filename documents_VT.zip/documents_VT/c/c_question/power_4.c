#include<stdio.h>
int main()
{
	int data;
	scanf("%d",&data);
	if((data&(data-1))==0)
	{
		if(!(data & 0xAAAAAAAA))
			printf(" power of 4");
		else
			printf("not power");	

	}
	else
		printf("not power");

/*	if((((data>>1)&1)==0) && (((data>>2)&1)==0))
		printf("power of 4");
	else
		printf("not power");*/
}
