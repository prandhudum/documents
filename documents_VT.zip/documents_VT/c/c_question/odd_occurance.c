#include<stdio.h>
int main()
{
	int i,res=0;
	int a[]={1,2,2,3,3,1,4,1,4};
	for(i=0;i<7;i++)
		res=res^a[i];
	printf("%d",res);
}
