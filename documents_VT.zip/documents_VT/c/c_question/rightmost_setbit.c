#include<stdio.h>
int main()
{
	int data,i,bit=32;
	scanf("%d",&data);
	for(i=0;i<bit;i++)
	{
		if(((data>>i)&1)==1)
		{
			data&=~(1<<i);
			break;
		}
	}
	printf("%d",data);


}
