#include<stdio.h>
int main()
{
int data,i;
printf("enter data:");
scanf("%d",&data);
for(i=31;i>=0;i--)
{
printf("%d",(~(data<<i)&1));
}
}
