#include<stdio.h>
int main()
{
	int d,i ,n,k;
	scanf("%d %d",&d,&n);
	for(i=0;i<sizeof(int)*8;i++)
	{
		if( ((d>>i)&1)==1)
		{
			break;
		}
	
	}
	for(k=i;k<sizeof(int)*8;k++)
	{
		n&=~(1<<k);
	}
	
	printf("%d",n);
}
