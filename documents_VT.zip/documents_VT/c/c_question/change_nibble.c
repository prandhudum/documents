#include<stdio.h>
int main()
{
int data=0x31,d;
//d=((data>>4)&0x0f) | ((data<<4)&0xf0);
d=data<<4;
printf("data=%x ,d=%x",data,d);

}

