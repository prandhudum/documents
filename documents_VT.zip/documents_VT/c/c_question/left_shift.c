#include<stdio.h>
int main()
{
       	char i,k,data,bit,cnt=1;
	scanf("%d",&data);
//	printf("%u",data);
	scanf("%d",&bit);
	for(i=7;i>=0;i--)
	{
		if(cnt<bit)
		{
			k=(data>>i)&1;
			data=data<<1;
			data|=k;
		}
		cnt++;
	}
	printf("%d",data);
}
