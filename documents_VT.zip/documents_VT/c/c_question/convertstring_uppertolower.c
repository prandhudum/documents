#include<stdio.h>
#include<string.h>
int main()
{
	char a[10]="prAnaLi";
	printf("%s",a);
	int i;
	for(i=0;i<strlen(a);i++)
	{
		if((a[i]>>5)&1)
		a[i]-=32;
		else
		a[i]+=32;
        }
	printf("%s",a);
}
