#include<stdio.h>
int main()
{
	int a=0x12345678;
	char *p=&a;
	char ptr[4];
	int i,j;
	for(j=3;j>=0;j--)
	{
		ptr[j]=*p;
		p++;

	}
	for(i=3;i>=0;i--)
		*(--p)=ptr[i];

	printf("%x",a);
}
