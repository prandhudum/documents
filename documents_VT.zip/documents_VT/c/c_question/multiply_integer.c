#include<stdio.h>
int main()
{
int data,result;
scanf("%d",&data);
result=(data>>1)+data+(data<<1);
printf("%d",result);
}
