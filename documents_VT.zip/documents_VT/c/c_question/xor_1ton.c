#include<stdio.h>
int main()
{
	int i, data,result=0;
	scanf("%d",&data);
	for(i=1;i<=data;i++)
		result^=i;
	printf("%d",result);


}
