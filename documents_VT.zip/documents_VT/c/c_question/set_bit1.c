#include<stdio.h>
int main()
{
	int n,cnt=0,rem;
	scanf("%d",&n);
	while(n>0)
	{
		rem=n%10;
		if(rem==1)
			cnt++;
		n/=10;
	}
	printf("%d",cnt);
}
