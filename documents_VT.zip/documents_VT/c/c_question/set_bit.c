#include<stdio.h>
int main()
{
	int data,set=0,i;
	scanf("%d",&data);
	for(i=0;i<sizeof(int)*8;i++)
		if((data>>i)&1)
			set++;
	printf("%d",set);
}
