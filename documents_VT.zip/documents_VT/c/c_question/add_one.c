#include<stdio.h>
int main()
{
int data;
scanf("%d",&data);
data=-(~data);
printf("%d",data);
}
