#include<stdio.h>
int main()
{
int i, a=10,b=5,cnt=0;
for(i=1;i<=sizeof(int)*8;i++)
{
if(((a>>i)&1)!=((b>>i)&1))
cnt++;
}
printf("%d",cnt);

}
