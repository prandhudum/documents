#include<stdio.h>
int main()
{
	int data,i,j,l,mul=1,k;
	char *p;
	printf("enter data");
	scanf("%d",&data);
	p=&data;
	for(i=3;i>=0;i--)
	{	
		l=*(p+i);
		for(j=7;j>=0;j--)
		{
			if((l>>j)&1)
			{
				k=j;
				while(k)
				{
					mul=mul*2;
					k--;
				}
			printf("%d",mul);
			mul=1;
			}
			else
			printf("%d",(l>>j)&1);
		}
	}

}
