#include<stdio.h>
int main()
{
 
    union test { 
        int i; 
        int j; 
    }; 
  
//    union test var = 10;
      union test var;
      var.i=9; 
    printf("%d, %d\n", var.i, var.j); 
} 

