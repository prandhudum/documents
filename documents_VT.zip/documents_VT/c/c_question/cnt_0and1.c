#include<stdio.h>
int main()
{
	int i,data,cnt=0,cnt1=0;
	scanf("%d",&data);
	for(i=1;i<sizeof(int)*8;i++)
	{
		if((data>>i)&1)
		{
			cnt++;
			//printf("%d",cnt);
		}
		else
		{
			cnt1++;
			//printf("%d",cnt1);
		}
//		printf("%d",cnt^cnt1);
	}
	printf("%d",cnt^cnt1);
}
