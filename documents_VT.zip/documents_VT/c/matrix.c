#include<stdio.h>
int main()
{
	int a[10][10],r,c,i,j,data;
	printf("Enter r & c");
	scanf("%d %d",&r,&c);
	for(i=0;i<r;i++)
	{
		j=0;
		 b:if(j<c)
		{
			scanf("%d",&a[i][j]);
			j++;
			goto b;

		}

	}
	for(i=0,j=0;i<r;i++,j++)
	{
		if(j<c)
		{
		printf("%d ",a[i--][j]);
		}
		else
		{
		j=-1;
		printf("\n");
		}
		
	}
}
