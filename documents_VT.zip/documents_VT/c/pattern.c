#include<stdio.h>
int main()
{
	int i,j,A,B,n,m;
	scanf("%d",&n);
        m=n;
	for(i=-(n-1);i<=(n-1);i++,printf("\n"))
	{
		for(j=-(n-1);j<=(n-1);j++)
		{
			A=i;j=B;
    			if(A<0)
			A=-A;
			if(B<0)
			B=-B;
			
			printf("%d",j);
		}
		m--;
	}
}
