#include<stdio.h>
main()
{
int *s;
s=(int*)malloc(1024*sizeof(int));
scanf("%s",s);
printf("%s",s);
}
