#include<stdio.h>
#include<string.h>
int main()
{
	char str[10],*str1;
        int i=0;
	printf("enter string");
	scanf("%s",str);
	str1=str;
	for(i=0;str[i];i++)
	{
		if(str[i]!='^')
		{
			printf("%c",str[i]);

		}
		else
		{
			i++;
			printf("%c",str[i]);
			memmove(str+i-1,str+i+1,strlen(str+i+1)+1);
			i=-1;
                 	printf("\n");
			
		}
	}
}
