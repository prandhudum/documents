#include<stdio.h>
typedef  char* CHAR;
int main()
{
  CHAR p1,p2;
printf("%u %u",sizeof(p1),sizeof(p2));

}
