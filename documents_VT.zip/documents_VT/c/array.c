/*#include<stdio.h>
int main() 
{ 
    int a[10]; 
    printf("%d",a[6]);
    printf("%d",*(a+1)-*(a+3)); 
    return 0; 
} */

#define a 10 
int main() 
{ 
  printf("%d ",a);   
  #define a 50 
  printf("%d ",a); 
    
  getchar(); 
  return 0; 
} 

