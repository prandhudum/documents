#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char *fun(char *str)
{
	char arr[]="madhab";
//	int len=strlen(arr);
	str=(char *)malloc(sizeof(char) *10);
	strcpy(str,arr);
	return str;

}

int main()
{
	char *ptr=NULL;
	ptr=fun(ptr);
	printf("%s",ptr);
}
