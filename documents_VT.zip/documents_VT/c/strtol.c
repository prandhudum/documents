#include<stdio.h>
int main()
{
char *p="kirtikumaricheguri";
char* end;
int n;
n=strtol(p,&end,10);
printf("%d",n);
}
