#include<stdio.h>
#include<sys/unistd.h>
int main()
{
printf("child=%d,parent=%d",getpid(),getppid());
}
