#include<stdio.h>
union data
{
	int n;
	union data *p;
};

int main()
{
	union data *obj;
	int n=0x12345678;
	int i,j;
	obj.p=&n;
	char *t;
	for(i=0,j=3;i<j;i++,j--)
	{
		t=obj.(p+i);
		obj.(p+i)=obj.(p+j);
		obj.(p+j)=t;
	}
	printf("%x",obj.p);

}
