#include<stdio.h>
#include<stdlib.h>
int main()
{
	char str[50];int n;double d;
	scanf("%d\n",&n);
	scanf("%ld\n",&d);
	fflush(stdout);
printf("%d",n);
         printf("%ld",d);


//	fflush(stdin);
	printf("enter string");
	gets(str);
	printf("%s",str);
//	 printf("%d",n);
//	 printf("%ld",d);

}
