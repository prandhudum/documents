#include<stdio.h>
int main()
{
	int data,p1,p2;
	printf("enter data:");
	scanf("%d",&data);
	printf("enter posiition:");
	scanf("%d %d",&p1,&p2);
	if(((data>>p1)&1)!=((data>>p2)&1))
	{
		printf("%d",data);
		data^=(1<<p1);
		data^=(1<<p2);
	}
	printf("%d",data);
}
