#include<stdio.h>

void func(int i)
{
	if(i>100)
		return;
	else
		printf("%d ",i);
			func(++i);
}
int main()
{
	func(1);
}
