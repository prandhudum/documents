#include<stdio.h>
#include<string.h>
int pop();
void push(const char arr[]);
int isfull();
int isempty();
static int top;
#define MAX 5
char stack[10];
int main()
{
	char str[10],st[10];
	int i,j=0,len;
//	for(i=0;i<MAX;i++)
//	{
		printf("enter elements:");
		scanf("%s",str);
//		push(&str[i]);

//	}
		printf("enter string to be search:");
		scanf("%s",st);
		len=strlen(st);
		for(i=0;i<len;i+=2)
		{
			//if(st[j]==str[i])
				push(st[i]);
		}
	


}

void push(const char ch)
{

	strcpy(stack[top],ch);
	printf("%s",stack[top]);
	top++;
}
