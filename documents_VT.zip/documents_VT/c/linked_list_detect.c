#include<stdio.h>
#include<stdlib.h>
struct st{
	int data;
	struct st *next;
};
struct st* create_list(struct st*head)
{
	struct st *temp=head;
	if(head !=NULL)
	{
	while(temp)
	{
		temp=temp->next;
	}
	
//	printf("%d",temp->data);
	temp=(struct st*)malloc(sizeof(struct st));
	printf("enter data");
	scanf("%d",&temp->data);
	printf("%d",temp->data);
	temp=temp->next;
	return head;
	}
	else
	{
	head=(struct st*)malloc(sizeof(struct st));
	printf("enter data");
	scanf("%d",&head->data);
	return head;
	}
}

void display(struct st*head)
{
	while(head)
	{
		printf("%d\n",head->data);
		head=head->next;
	}
}
int main()
{
	struct st*head=NULL;
	int ch;
	while(1)
	{
	printf("1.create");
	printf("2.display");
	printf("enter choice:");
	scanf("%d",&ch);

		switch(ch)
		{
			case 1:head=create_list(head);
				break;
			case 2:display(head);
				break;
		}
	}
}
