#include<stdio.h>

int main() {

    int i,j=0,cnt;
    char *s=(char*)malloc(1024*sizeof(char));
    scanf("%s",s);
    for(i=0;s[i];i++)
    {
	if(s[i]-48==j)
	 cnt++;
    }
    return 0;
}


