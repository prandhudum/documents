int main()
{
	printf("%c\n",65);
}
