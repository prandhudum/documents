#include<stdio.h>
#define SIZE 3
void push1(int);
void push2(int);
void push3(int);
int pop();
int pop2();
int pop3();
int empty();
int full();
 int top1=-1;
int top2=-1;
int top3=-1;
int stack[SIZE];
int stack2[SIZE];
int stack3[SIZE];
int main()
{
	int data,ch,element;
	printf("enter data in stack1\n");
	while(1)
	{
		printf("1.push in stack1 \n 2.pop from stack1 \n 3.push in stack2\n  4.merge 5. pop from stack2 \n  6.exit\n");
		scanf("%d",&ch);


		switch(ch)
		{
			case 1:if(full())
			       {
				       printf("stack1 is full");
				       return(0);
			       }
			       else
			       {
				       printf("enter data");
				       scanf("%d",&data);
				       push1(data);
				       //	printf("%d",top1);
			       }
			       break;

			case 2:if(empty())
			       {
				       //	printf("%d",top1);
				       printf("stack is empty");
				       return(0);
			       }
			       else{
				       element=pop();
				       printf("pop data  is %d",element);
				       push3(element);

			       }
			       break;

			case 3:if(full())
			       {
				       printf("stack2 is full");
			       }
			       else	
			       {
				       printf("enter data:");
				       scanf("%d",&data);
				       push2(data);
				       //	printf("%d",top2);
			       }
			       break;
			case 4:element=pop3();
			       printf("pop element %d",element);
			       push2(element);
			       break;
			case 5: printf("pop element from stack2 %d",pop2());
			       break;

			case 6:return(0);

		}
	}

}

void push1(int data)
{
	top1++;
	//printf("%d",top1);
	stack[top1]=data;
}

void push2(int data)
{
	top2++;
	stack2[top2]=data;
}

void push3(int data)
{
	top3++;
	stack3[top3]=data;
	printf("%d",stack3[top3]);
}
int full()
{
	if(top1==SIZE)
		return 1;
	return 0;
}

int empty()
{
	if(top1==-1)
		return 1;
	return 0;
}

int pop()
{
	return stack[top1--];
}

int pop2()
{
	return stack2[top2--];
}

int pop3()
{
	return stack3[top3--];
}
