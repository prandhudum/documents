#include<stdio.h>
#define PTR char*
int main()
{
PTR a,b;
printf("%u\n%u",sizeof(a),sizeof(b));
}
