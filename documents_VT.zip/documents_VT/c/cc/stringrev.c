#include<stdio.h>
#include<string.h>
void * stringrev(char *a,int n)
{
	if(!(*a))
		return *a;
	else
		{
                       
		return stringrev(++a,--n);
			//printf("%c",*a);
		}
}
int main()
{
	char a[10]="hello";
	int n;
	n=strlen(a)-1;
//        stringrev(a,n);
	
	printf("%s",stringrev(a,n));
}
