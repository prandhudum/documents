#include<stdio.h>
int main()
{
	int i,k=1;
	for(i=0;i<5;i++)
	{
		if(k>i)
		printf("hi");
		continue;
	}
}
