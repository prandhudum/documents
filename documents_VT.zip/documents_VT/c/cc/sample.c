#include<stdio.h>
int d=3;
static int e=4;
int main()
{
int a;
int b=1;
static int c=2;
}
