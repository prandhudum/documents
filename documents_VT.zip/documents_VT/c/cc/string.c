#include<stdio.h>
#include<string.h>
int main()
{
char str[]="hello";;
char i,j;
//printf("%s",str);
char *p=str;
for(j=0,i=strlen(str)-1;i>j;i--,j++)
{
printf("%s\n",str);
*(p+j)^=*(p+i)^=*(p+j)^=*(p+i);
//*(p+i)^=*(p);
//(*p)^=*(p+i);
}
printf("%s",str);
//putchar(*p);
}
