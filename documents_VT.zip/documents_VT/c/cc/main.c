#include<stdio.h>
void fun()
{
	printf("hi");
}

//int main()
//{
//	fun();
//}
