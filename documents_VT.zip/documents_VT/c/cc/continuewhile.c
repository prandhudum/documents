#include<stdio.h>
int main()
{
	int i,k=1;
	i=0;
	/*	while(i<5)
		{
		if(k>i)
		printf("hi");
		i++;
		continue;
	//	i++;
	}*/
	do{
		if(k>i)
		printf("hi");
		continue;
	}	while(i++<5);

	
}
