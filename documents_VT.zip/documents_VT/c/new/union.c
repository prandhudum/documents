#include<stdio.h>
union uday {
int a;
};

int main()
{
union uday u1;
u1.a=6;
printf("%d",u1.a<<2);
}
