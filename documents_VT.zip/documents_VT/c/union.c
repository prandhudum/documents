#include<stdio.h>
#pragma pack(1)
union u1
{
	int i;
	struct st{
		double d;
		long double c;
//		char c;
	}s;
	//int i;
};

int main()
{
	union u1 u;
	//struct st s1;
	printf("%d",sizeof(u));
}
