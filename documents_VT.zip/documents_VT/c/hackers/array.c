#include<stdio.h>
int main() 
{
    int a, b,i;
    char **ch={'one','two','three','four','five','six','seven','eight','nine'};
    scanf("%d\n%d", &a, &b);
    for(i=0;i<9;i++)
    {
        if(i==a)
            printf("%s",ch[i]);
        else if(i==b)
            printf("%s",ch[i]);
    }
    if(a>9 || b>9)
    {
        printf("nine");
    }

    if(a%2==0)
        printf("even");
    else
        printf("odd");
    
    if(b%2==0)
        printf("even");
    else
        printf("odd");

    
  	// Complete the code.

    return 0;
}

