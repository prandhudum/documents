#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	FILE *fp=NULL;
	int i=0,j,number,cnt=0;
	char (*buffer)[100]=NULL;char temp[100];char a[10];
	fp=fopen("pranali.txt","r");
	if(fp==NULL)
	{
		printf("error");
	}
	
	printf("enter input");
	scanf("%d",&number);
	while(fgets(temp,100,fp))
	{       
		buffer=realloc(buffer,(cnt+1)*100);
		strcpy(buffer[cnt],temp);
		if(((*buffer[cnt])-48)==number)
		{
			
			printf("%s",(buffer[cnt]));
		}
		cnt++;	
	}

	fclose(fp);
}
