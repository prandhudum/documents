#include<stdio.h>
#include<string.h>
int pop();
void push(const char arr[10]);
int isfull();
int isempty();
static int top;
#define MAX 5
char stack[10];

void push(const char str[10])
{
strcpy(stack[top],str);
top++;
printf("%s",stack[top]);
}
int main()
{
	char st[10],str[10];
         int i,length;	

		printf("enter string to be pushed:");
		scanf("%s",st);
		printf("enter string to be searched:");
		scanf("%s",str);
		length=strlen(str);
		for(i=0;i<length;i+=2)
		{
			push(st[i]);
		}		

}





