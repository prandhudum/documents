#include<stdio.h>

int main() {

    int i=0,j,cnt;
    char *s=(char*)malloc(1024*sizeof(char));
    scanf("%s",s);
    do{
        cnt=0;j=0;
        
        while(s[j])
        {
            if((int)s[j]==i)
            cnt++;
            j++;
        }
        printf("%d ",cnt);
        
    }while(i++<10);
    return 0;
}


