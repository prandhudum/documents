#include<stdio.h>
#include<stdlib.h>
void fun(int **p)
{
*p=(int*)malloc(sizeof(int));
**p=8;
}
int main()
{
int *p=NULL;
fun(&p);
//*p=3;
printf("%d",*p);
}
