#include<stdio.h>
int main()
{
const  int p=6;
int *ptr=(int*)&p;
if(*ptr==6)
printf("little");
else
printf("bib");
}
