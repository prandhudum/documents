#include<stdio.h>
#include<stdlib.h>
#define SIZE 5
void push();
int pop();
int empty();
int full();
 int top=-1;
 int stack[SIZE];
int main()
{
	int data,ch;
	while(1)
	{
	printf("1.push  2.pop 3.exit\n");
	scanf("%d",&ch);
	
	
		switch(ch)
		{
			case 1:if(full())
				{
				       printf("stack is full");
					return(0);
				}
			       else
				       printf("enter data");
			       scanf("%d",&data);
			       push(data);
			       break;

			case 2:if(empty())
				{
				       printf("stack is empty");
					return(0);
				}
			       else
				       printf("pop data  is %d",pop());
			       break;
			case 3:exit(0);

		}
	}

}

void push(int data)
{
top++;
stack[top]=data;

}

int full()
{
if(top==SIZE)
return 1;
return 0;
}

int empty()
{
if(top==-1)
return 1;
return 0;
}

int pop()
{
return stack[top--];

}
