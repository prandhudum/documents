#include<stdio.h>
int main()
{
char a='A';
//printf("%d",sizeof(a)>b);
//printf("%d",-1^c);
char *x,*y;
x=&a;
y=&a;
++x;
if(x>y)
printf("bottom up");
else
printf("top down");
}
