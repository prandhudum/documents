#include<iostream>
using namespace std;
static int cnt;


class A
{
	public:
		float x,y;
		//int dis;
		A *calculate(A a[],int n,int k,A a1);
};

int squre(int k)
{
	int count=0,sq=0,i=k;
	while(i > 0)
	{
		if((i & 1) == 1)
		{
			sq += k << count;
		}

		i = i >> 1;
		count++;
	}

	return sq;
}
A* A::calculate(A a[],int n,int k,A a1)
{
	int dis;
	k=squre(k);
	//	static A a2[10];
	static A *a2=new A[n];

	int j=0;
	for (int i=0;i<n;i++)
	{
		dis=((a1.y-a[i].y)*(a1.y-a[i].y))+((a1.x-a[i].x)*(a1.x-a[i].x));

		if(dis==k)
		{
			cnt++;
			//			static A *a2=new A[cnt*2];
			a2[j].x=a[i].x;
			a2[j].y=a[i].y;
			j++;

		}
	}
	cout<<"cnt:"<<cnt<<endl;
	return a2;    
}


int main()
{

	//A a[10];
	A a1;
	A *p=NULL;
	int n,k,x,y;
	cout<<"enter x and y:"<<endl;

	cin>>a1.x>>a1.y;	
	cout<<"enter n"<<endl;
	cin>>n;
	cout<<"enter k"<<endl;
	cin>>k;
	A *a=new A[n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i].x;
		cin>>a[i].y;
	}
	p=a1.calculate(a,n,k,a1);
	for(int i=0;i<cnt;i++)
	{
		cout<<p[i].x;
		cout<<",";
		cout<<p[i].y;
		cout<<" ";
	}
	delete []a;

}
