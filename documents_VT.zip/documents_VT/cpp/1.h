#ifndef _1_H
#define _1_H

struct a{
int data;
};
#endif
