#include<iostream> 
using namespace std; 
//static  const int a=2;
void fun(void);

class A
{
static const int a;
public:
//static const int a=1;
void fun()
{
//a++;
cout<<a;
}

};
//int A::a=2;
int main()
{
A a;

a.fun();
a.fun();
}

/*void fun(static char *s=0)
{
static const char* a;
//a=a+1;
if(*s)
a++;
else
a=1;
cout<<a;
}*/
