#include<iostream>
using namespace std;
#include<math.h>
class coordinate
{
	float x[10],y[10],x1,y1;
	int k,n,dis;
	static int cnt;
	public:
	coordinate()
	{
		cout<<"enter distance"<<endl;
		cin>>k;
		cout<<"enter no of coordinate"<<endl;
		cin>>n;
	}
	void input()
	{
		for(int i=0;i<n;i++)
			cin>>x[i]>>y[i];
	}
	int calculate()
	{
		for(int i=0;i<n;i++)
		{
			dis=sqrt(((y1-y[i])*(y1-y[i]))+((x1-x[i])*(x1-x[i])));
			if(k==dis)
				cnt++;
		}
		return cnt;
	}
	void ref()
	{
		cout<<"enter center point"<<endl;
		cin>>x1>>y1;
	}
};
int coordinate::cnt=0; 
int main()
{
	coordinate c;
	c.input();
	c.ref();
	cout<<"cnt="<<c.calculate()<<endl;
}
