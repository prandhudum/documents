#include<stdio.h>
#include<stdlib.h>
void sam();
//extern "c"  void sam();
int main()
{
sam();
}
/*void fun()
{
printf("hi");
}*/
