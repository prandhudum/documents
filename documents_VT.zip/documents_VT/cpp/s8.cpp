#include<iostream>
using namespace std;
//const int h;
class A
{
const int i;
public:
void get()
{
cout<<i;
}
};
int main()
{
A a;
a.get();
//const int i;
//cout<<h;
}
