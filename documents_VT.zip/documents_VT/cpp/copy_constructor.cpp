#include<iostream>
using namespace std;
class A
{
	int a;
	public:
	A(){a=2;}
	A( A &b)
	{
		a=b.a;
		cout<<"a="<<a<<endl;
	}
	A& fun()
	{
		A a2;
		cout<<"in fun"<<endl;
		cout<<"a="<<a2.a<<endl;
		return a2; 
	}
};

int main()
{
	A a1;
	A a2=a1;
	a2.fun();
//	cout<<"fun value"<<a1.fun()<<endl;
}
