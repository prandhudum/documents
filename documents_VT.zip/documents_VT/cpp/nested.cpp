#include<iostream>
using namespace std;
class A
{
         int x;
	public:
	class B
	{
		public:
		
	        int y;
		void put()
		{
			A a1;
			a1.x=2;
			cout<<"x="<<a1.x<<endl;
		}
	
	};
};

int main()
{
A::B b1;
b1.y=9;

//b1.put();
cout<<"y="<<b1.y;
}
