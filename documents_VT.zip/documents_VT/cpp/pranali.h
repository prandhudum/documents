#ifndef _PRANALI_H_
#define _PRANALI_H_
#include<iostream>
using namespace std;
struct st{

        float x,y;
        int dis;
};

st * calculate(st s[],int,int,int,st);






#endif
