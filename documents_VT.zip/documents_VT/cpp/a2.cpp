#include<iostream>
using namespace std;
 const int a=100;
void uday(int);
int main()
{
cout<<"a="<<a<<endl;
cout<<"&a="<<&a<<endl;
uday(a);
}
