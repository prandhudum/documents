#include<iostream>
using namespace std;
class A
{	int a;
	public:
		A(){a=1;}
		void fun()
		{
			cout<<"a="<<a<<endl;
		}
		void fun(int x,int y)
		{
			cout<<"x="<<x<<"y="<<y<<endl;
		}
		void fun(double x,int y)
		{
			cout<<"x="<<x<<"y="<<y<<endl;
		}
};
int main()
{
	A a1;
	a1.fun();
	a1.fun(2,3);
	a1.fun(2.3,5);
}
