int fun(int a,float b);
