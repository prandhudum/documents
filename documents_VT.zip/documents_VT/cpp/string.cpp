#include<iostream>
using namespace std;
main()
{
string s;
getline(cin,s);
//cin>>s;
cout<<s;

}
