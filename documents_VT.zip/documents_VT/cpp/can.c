#include<stdio.h>
int measure(int a,int b,int c,int d,int k)
{
	static int cnt;
	if(k==a)
		return cnt;
	else
	{
		cnt++;
		if(0==a)
			a=c;
		else if(b==d)
		{
			b=0;
		}
		else if(a<=d)
		{
			b=a;
			a=0;
		}
		else 
	        {
			a-=d-b;
			b+=d-b;
			
		}

		return measure(a,b,c,d,k);

	}
}

int main()
{
	int a,b,c,d,k,p;
	printf("capacity of a bottle:");
	scanf("%d",&a);

	printf("capacity of b bottle:");
	scanf("%d",&b);

	printf("measure:");
	scanf("%d",&k);

	c=a;
	d=b;
	p=measure(0,0,c,d,k);
	printf("cnt:%d",p);
}
