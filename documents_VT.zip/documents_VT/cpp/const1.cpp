#include<iostream>
using namespace std;
class stu
{
	const int r;
	public:
	 stu(int a)
{

}
	void put(int x) :r(x){} 
};
// stu::stu(int a):r(a)
//{
//this->r=r;
//r=a;
//}
/*
void stu::put()
{
	cout<<r<<endl;}
*/
int main()
{
	stu s(2);
	//s.get(2);
	s.put(3);
}
