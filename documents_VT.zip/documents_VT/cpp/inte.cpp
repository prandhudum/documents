#include<iostream>
using namespace std;
void func(int &p)
{
cout<<p;
}
int main()
{
float m=1.23;
func(m);
cout<<m;
}
