#include<iostream>
using namespace std;
class A{
int a;
public:
A()
{
cout<<"*";
//this->a=a;
}
~A()
{
cout<<"des"<<endl;
}
void show()
{
cout<<"hi"<<endl;
}

};
int main()
{
A *p=new A[20];
delete []p;
p->show();

}
