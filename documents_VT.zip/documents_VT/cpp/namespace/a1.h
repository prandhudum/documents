namespace a1
{
class b
{
int a;
};
}
