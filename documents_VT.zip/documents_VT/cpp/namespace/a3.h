#include"a1.h"
using namespace a1;
namespace a3
{
class b
{
int v;
};
}
