
void foo1(void);
namespace sam
{
int a;
class A{
public:
//void foo();
};
void foo1(){}
}

int main()
{
sam::A data;
// s.foo();
sam::foo1();
}
