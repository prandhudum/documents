//#include<iostream>
//using namespace std;
#include"a3.h"
#include"a2.h"
using namespace a2;
int main()
{
 b c1;
}
