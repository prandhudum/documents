namespace a2
{
class b
{
int c;
};
}
