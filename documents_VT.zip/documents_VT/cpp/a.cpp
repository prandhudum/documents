#include"pranali.h"

int main()
{
        st s[10],s2;
        st *p;
        int n,k,i,x,y;
        cout<<"enter x and y:"<<endl;
        cin>>s2.x>>s2.y;
        cout<<"enter n"<<endl;
        cin>>n;
        cout<<"enter k"<<endl;
        cin>>k;
        for(i=0;i<n;i++)
        {
        cin>>s[i].x;
        cin>>s[i].y;
        }
        p=calculate(s,n,k,s2);
        for(i=0;i<cnt;i++)
        {
                cout<<p[i].x;
                cout<<",";
                cout<<p[i].y;
                cout<<" ";
        }

