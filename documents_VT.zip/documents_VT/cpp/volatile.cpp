#include<iostream>
using namespace std;
int main()
{
const  volatile int i=2;
cout<<i;
i++;
cout<<i;

}


