#include <stdio.h>
static inline void hello()
{
	printf("hello\n");
}
int main()
{
	hello();
}
