#include<iostream>
using namespace std;
class A
{
/*private:
A(){
cout<<"in private"<<endl;}*/
protected:
A(){
cout<<"in protected"<<endl;}
public:
A(){
cout<<"in public"<<endl;}
};

class B:private A
{
A a;
};
int main()
{B b;
}
