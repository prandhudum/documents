#include<iostream>
using namespace std;
class Test
{
	static int x;
	public:
	Test(){x++;}
	static int getx(){return 0;}
};
int Test::x=0;
int main()
{
	cout<<Test::getx()<<endl;
	Test t[5];
	cout<<Test::getx();
	cout<<Test::getx();
}
