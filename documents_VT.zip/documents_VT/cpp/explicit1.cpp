#include<iostream>
using namespace std;
class String
{
public:
explicit String(int n)
{
cout<<n<<endl;
}
};
int main()
{
String mystring=(String)'x';
}
