#include<iostream>
using namespace std;
int main()
{
string s;
cout<<sizeof(s);
}
