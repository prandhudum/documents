#include<iostream>
using namespace std;
#include<math.h>

class calculate{
int j,l,m;
float dis;
static int cnt;
int x[20],y[20];
public:
calculate()
{
j=0,l=0,m=0;
}
int * cal(int a[],int n,int x1,int y1,int k)
{
		for(int i=0;i<n;i++)
		{
			x[l]=a[i];
			y[m]=a[++i];
			l++;m++;
		}

                for(int i=0,l=0,m=0;(l<n/2)&&(m<n/2);i++,l++,m++)
                {
                        dis=sqrt(((y1-y[m])*(y1-y[m]))+((x1-x[l])*(x1-x[l])));
                        if(k==dis)
			{
                                cnt++;
				a[j]=x[i];
				a[++j]=y[i];
				j++;
				
			}
                }
		 cout<<"cnt="<<cnt<<endl;

return a;
}

};
int calculate::cnt=0; 
class coordinate{
int *p;
	public:
		
		coordinate(int a[],int n,int x1,int y1,int k)
		{  
			calculate c1;
			p=c1.cal(a,n,x1,y1,k);
			for(int i=0;i<n;i++)
				cout<<p[i]<<endl;
		}
};
class input{
int a[30];
int x1,y1;
int n;
float k;

public:
input()
{
		cout<<"enter n:"<<endl;
		cin>>n;
		cout<<"enter array:"<<endl;
		for(int i=0;i<n;i++)
                cin>>a[i];;
		cout<<"enter x1,y1,k:"<<endl;
		cin>>x1>>y1>>k;
		coordinate c(a,n,x1,y1,k);

}


}; 
int main()
{
      
	input i;

}
