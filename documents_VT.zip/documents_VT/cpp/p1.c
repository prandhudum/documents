#include<stdio.h>
#include<string.h>
#define MAX 10
void push(char);
int pop();
int full();
int empty();
int top=-1;
int stack[MAX];
int main()
{
	char str[10],chr;int len,i;
	printf("enter string:");
	scanf("%s",str);
	len=strlen(str);
	for(i=0;i<len;i++)
	{
		if(str[i]=='{'||str[i]=='['||str[i]=='(')
		{
			push(str[i]);
		}
		else if(str[i]==')')
		{
			chr=stack[pop()];
			if(chr!='(')
			{
				
				break;
			}
		}
		else if(str[i]==']')
		{
			chr=stack[pop()];
			if(chr!='[')
			{
				
				break;
			}
		}
		else
		{
			chr=stack[pop()];
			if(chr!='{')
			{
				
				break;
			}
	        }
		
	}
	printf("%d",top);
	if(top==-1)
		printf("compilation successful");
        else
		printf("compilation failed");

}

void push(char ch)
{
	if(full())
	{
		printf("stack is full");
	}
	else
	{
		top++;
		stack[top]=ch;
	}
}

int pop()
{
	if(empty())
	{
		printf("stack is empty");
	}
	else
		return top--;
}

int full()
{
	if(top==MAX+1)
		return 1;
	else
		return 0;
}

int empty()
{
	if(top==-1)
		return 1;
	else 
		return 0;
}
