#include<iostream>
using namespace std;

class A{

public:
inline void sam();
};

inline void A::sam()
{
cout<<"hi";
}
int main()
{
A a;
a.sam();
}
