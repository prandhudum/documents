#include<stdio.h>
int main()
{
printf("%d",a);
}
