#include<stdio.h>
#include<string.h>
int main()
{
int *ptr="pranali";
strcpy(ptr,"sds");
printf("%s",ptr);
}
