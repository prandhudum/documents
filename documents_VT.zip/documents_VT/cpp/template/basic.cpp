#include<iostream>
using namespace std;

template<typename T,typename U= int>
class A{
T a;
U b;
public:
void swap(T a);

};
template<typename T,typename U>


void A<T,U>::swap(T a,U b)
{
T temp;
temp=a;
a=b;
b=temp;
}
int main()
{

A<int,7>s;
s.swap(1);
//A<float,float>swap(2.2,3.3);
}
