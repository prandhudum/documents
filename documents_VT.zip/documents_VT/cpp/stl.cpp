#include<algorithm>
#include<iostream>
using namespace std;
int main()
{
int a[10];
for(int i=0;i<6;i++)
cin>>a[i];
reverse(a,a+6);
for(int i=0;i<6;i++)
cout<<a[i];
if(binary_search(a,a+6,5))
cout<<"prasent";
else
cout<<"not prasent";

}
