#include<iostream>
using namespace std;
class A
{
	public:
		A()
		{
			cout<<"in A"<<endl;
		}
		 void sam()
		{
			cout<<"hi"<<endl;
		}
};

class B: virtual public A
{
	public:
		B()
		{
			cout<<"in B"<<endl;
		}
		void sam()
		  {
		  cout<<" sam:B"<<endl;
		  }
};
class C :  virtual public A
{
	public:

		C()
		{
			cout<<"in c"<<endl;
		}

		void sam()
		  {
		  cout<<"sam : c"<<endl;
		  }

};
class D :  public B,  public C 
{
	public:
		D()
		{
			cout<<"in D"<<endl;
		}

		void sam()
		{
			cout<<"sam : D"<<endl;
		}

};

int main()
{
//	A *a;
	D d;
//	a=&d;
	
	d.A::sam();
//	a->sam();
	
}
