#include<iostream>
using namespace std;
int main()
{
int p;
char *o=&p;
}
