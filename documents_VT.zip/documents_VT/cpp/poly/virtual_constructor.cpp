#include<iostream>
using namespace std;
class A {
public:
  virtual ~A() {}
  virtual A * Clone() { return new A;}
};
class B : public A {
public:
  virtual A * Clone() { return new B; }
};

int main() {

   A * a1 = new B;
   A * a2 = a1->Clone();    // virtual construction
   delete a2;
   delete a1;
}
