#include<iostream>
using namespace std;
class shape{
public:
void area();
};
class circle:public shape
{
public:
void area()
{
cout<<"in circle";
}
};
int main()
{
circle c;
c.area();
}
