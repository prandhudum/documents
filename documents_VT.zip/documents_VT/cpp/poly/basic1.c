#include<stdio.h>

int main()
{
int p;
char *o=&p;
}
