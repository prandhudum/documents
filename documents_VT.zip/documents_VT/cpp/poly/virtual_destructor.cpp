#include<iostream>
using namespace std;
class A{

public:
A(){cout<<"A constructor"<<endl;}
 virtual ~A()=0;
};
A::~A(){cout<<"A destructor"<<endl;}

class B:public A
{

public:
B(){cout<<"B constr"<<endl;}
~B(){cout<<"B des"<<endl;}
};

int main()
{
//B *b=new B;
//delete b;
B b;
}
