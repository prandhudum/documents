num=4
if num>7 :
	print("hi")
else:
	print("hlo")

