#include<iostream>
using namespace std;
int main()
{
int f=3.4;
float i=f;
float b=static_cast<float>(f);
cout<<b<<endl;
cout<<i;
}
