#include<iostream>
using namespace std;
class A{

public:
virtual A()
{
cout<<"in A";
}
};
int main()
{
A a;
}
