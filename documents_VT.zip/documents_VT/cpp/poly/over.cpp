#include<iostream>
using namespace std;
class A
{
	public:
	virtual	void fun1()
		{
			cout<<"in A"<<endl;
		}
	virtual void fun2(int a)
		{
			cout<<"in A"<<endl;
		}
};
class B:public A
{
	public:

		void fun1()
		{
			cout<<"in B"<<endl;
		}
};
main()
{
//	A *p=new A();
//	p->fun();
	B b;
//	b.fun1();
//	b.fun1(1);
//	b.fun(2);
        A &a1=b;
	b.fun1();
	b.fun2(1);
}
