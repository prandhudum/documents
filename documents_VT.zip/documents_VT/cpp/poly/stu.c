#include<stdio.h>
struct s{
char c;
long int v;
int h;

};
int main()
{
struct s s1;
printf("%d",sizeof(s1));
}
