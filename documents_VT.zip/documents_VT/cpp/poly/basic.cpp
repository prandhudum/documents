#include<iostream>
using namespace std;
class A{
	public:
	virtual void fun()
		{cout<<"in A"<<endl;}
	
};
class B
{
	public:
		virtual void fun()
		{cout<<"in B";}
		virtual void f()
		{cout<<"in b";}
};

class c{

	public:
		void fun()
		{cout<<"in c";}
		void f()
		{cout<<"in c";}
};

class D{

	public:
		void fun()
		{cout<<"in d";}
};

void fun1(A &i)
{
	i.fun();
}

int main()
{
	
	B b;
	c c1;
	D d;
	cout<<sizeof(b)<<endl;
	cout<<sizeof(c1)<<endl;
//	fun1(b);
//	fun1(c1);
//	fun1(d);
	//fun1(a);
//	fun1(b);
}
