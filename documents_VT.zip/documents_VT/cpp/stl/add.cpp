#include<iostream>
using namespace std;
float sum(float a,float b)
{
	return a+b;
}
int main()
{
	float a,b;
	cin>>a>>b;
	cout<<sum(a,b);
}
