#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int> v1;
vector<int> ::iterator i1;
	for(i1=v1.begin();i1!=v1.end();i1++)
		v1.push_back(*i1);
	for( i1=v1.begin();i1<v1.end();i1++)
		cout<<*i1<< " ";

}
