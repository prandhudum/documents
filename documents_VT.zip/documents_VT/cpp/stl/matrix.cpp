#include<iostream>
#include<vector>
using namespace std;
class matrix
{
	 int multiply_value(int m,int n)
                {
                        int ans = 0, count = 0; 
                        while (m) 
                        { 

                                if (m % 2 == 1)               
                                        ans += n << count; 

                                count++; 
                                m /= 2; 
                        } 
                        return ans; 
                }

	public:
		vector<vector<int> > multiply_matrix(vector<vector<int> >&m1,vector<vector<int> >&m2)
		{
			//	vector<vector<int> >v2(m1.size(),vector<int>(m2[0].size(),0));
			vector<vector<int> >v2;
			int row=m1.size();
			int col=m2[0].size();

			for(int i=0;i<row;i++)
			{
				vector<int> mul;
				for(int j=0;j<col;j++)
				{
					int sum=0;
					for(int k=0;k<m2.size();k++)
					{
						//sum+=m1[i][k]*m2[k][j];
							sum+=multiply_value(m1[i][k],m2[k][j]);
					}
				
					mul.push_back(sum);

				}
				v2.push_back(mul);
				cout<<endl;

			}
			return v2;
		}

};
int main()
{
	matrix m;
	int r1,c1,r2,c2,value;
	cin>>r1>>c1;
	vector<vector<int> > m1;
	vector<vector<int> >m2;
	vector<vector<int> >mul;
	for(int i=0;i<r1;i++)
	{
		//m1.push_back(vector<int> ());
		vector<int> col1;
		for(int j=0;j<c1;j++)
		{	
			cin>>value;
			//m1[i].push_back(value);
			col1.push_back(value);
		}
		m1.push_back(col1);
	}
	for(int i=0;i<r1;i++)
	{
		for(int j=0;j<c1;j++)
			cout<<m1[i][j]<<" ";
		cout<<endl;
	}

	cin>>r2>>c2;

	for(int i=0;i<r2;i++)
	{
		//m1.push_back(vector<int> ());
		vector<int> col2;
		for(int j=0;j<c2;j++)
		{
			cin>>value;
			//m1[i].push_back(value);
			col2.push_back(value);
		}
		m2.push_back(col2);
	}
	for(int i=0;i<r2;i++)
	{
		for(int j=0;j<c2;j++)
			cout<<m2[i][j]<<" ";
		cout<<endl;
	}

	mul=m.multiply_matrix(m1,m2);
	for(int i=0;i<m1.size();i++)
	{
		for(int j=0;j<m2[0].size();j++)
			cout<<mul[i][j]<<" ";
		cout<<endl;
	}


}
