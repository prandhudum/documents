#include<iostream>
#include<array>
#include<forward_list>
using namespace std;
int main()
{
	forward_list<int> arr;
	for(int i=0;i<6;i++)
//		cout<<arr.at(i)<<endl;
	arr.push_front(5);
	for(int& c:arr)
	cout<<c<<endl;

}
