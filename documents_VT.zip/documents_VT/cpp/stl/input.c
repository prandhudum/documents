#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() 
{

     char c1,c2[10],c3[25];
     scanf("%c",&c1);
     printf("%c\n",c1);
     scanf("%s",c2);
     printf("%s\n",c2);
    // gets(c3);
     scanf("\n%[^\n]s",c3);
     //scanf("%10[0-9a-zA-Z ]", &c3);
     printf("%s",c3);
}
