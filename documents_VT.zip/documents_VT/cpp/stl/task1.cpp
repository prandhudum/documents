#include<iostream>
#include<vector>
#include<list>
using namespace std;
main()
{
	list<int> v1;
	char ch;
	int no_testcases,no_query,data;
	cin>>no_testcases;
	cin>>no_query;
	for(int i=0;i<no_query;i++)
	{
		cin>>ch;
		switch(ch)
		{
		case 'a':cin>>data;
		       v1.push_back(data);
		       break;
		case 'c':v1.reverse();
		       break;
		
		case 'b':v1.sort();
		       break;
		
		case 'e':/*for(int i=0;i<v1.size();i++)
			cout<<v1[i]<<" ";*/
			list <int> :: iterator it; 
   			 for(it = v1.begin(); it != v1.end(); ++it) 
        		 cout << '\t' << *it; 
			break;
		}
	}

}
