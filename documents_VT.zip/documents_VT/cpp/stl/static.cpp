#include<iostream>
using namespace std;
int main()
{
double d;
cin>>d;
cout<<static_cast<double>(d);
}
