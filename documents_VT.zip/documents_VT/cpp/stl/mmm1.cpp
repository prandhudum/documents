#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;
class A
{
      	float mean=0,rem=0;

	int mid;
	int cnt=0,cnt1=0,element;
	public:
 	 
	float mean1(vector< int>const& v)
	{
		for(auto i=v.begin();i<v.end();i++)
		{
			try
			{
				if(*i>65536)
				throw(*i);
			}
			catch(...)
			{
				cout<<"pushed elements is beyond limit"<<endl;
				return 0;
			}
		}
		for(auto i=v.begin();i<v.end();i++)
		{
				rem+=(*i)%v.size();
		//	mean+=(static_cast<float>(*i))/v.size();
			//cout<<fixed<<setprecision(3)<<endl;
			mean+=(*i)/v.size();
		}
		if(rem>9)
	        mean+=(rem/v.size());
		
		return mean;
	}
	int median(vector<int> &v)
	{
		sort(v.begin(),v.end());

		for(auto i=v.begin();i<v.end();i++)
		{
			cout<<*i<<" ";
		}
		cout<<endl;
		if(0==(v.size()%2))
		{
			mid=((v.size())/2)+1;


		}
		else
		{
			mid=((v.size()+1))/2;
		}

		return v[mid-1];
	}
	vector<int> mode(vector<int> v)
	{
		vector<int> v1;
		sort(v.begin(),v.end());

		for(int i=0;i<v.size();i+=cnt)
		{
			cnt=count(v.begin(),v.end(),v[i]);
			if(cnt==cnt1)
			{
				cnt1=cnt;
				v1.push_back(v[i]);
			}
			else if(cnt>cnt1)
			{
				cnt1=cnt;
				if(!(v1.empty()))
				while(!(v1.empty()))
				v1.pop_back();
				
				v1.push_back(v[i]);
			}
		}
		return v1;
	}



};



int main()
{
	//vector< int> v1,v;
	vector<int>v1,v;
	A a1;

	int value,number;
        float f;
//	T f;
	cout<<"no of elements:"<<endl;
	cin>>number;
 	for(int i=0;i<number;i++)
	{
	    cin>>value;
	    v1.push_back(value);
	}
//	cin>>value;*/
	f=a1.mean1(v1);
	if(f)
	cout<<f;
/*	else
	{
	cout<<"push back elements"<<endl;
	goto b;
	}*/
	//cout<<a1.mean1(v1)<<endl;
//	cout<<a1.median(v1)<<endl;
//	v=a1.mode(v1);
//	for(auto i=v.begin();i!=v.end();i++)
//	cout<<*i<<endl;
	

}
