#include<iostream>
#include<algorithm>
using namespace std;
void show(int arr[])
{
	for(int i=0;i<7;i++)
	{
		cout<<arr[i];
	}
}
int main()
{
	int arr[10]={3,1,6,4,7,8,2};
	show(arr);
	sort(arr,arr+6);
	show(arr);
}
