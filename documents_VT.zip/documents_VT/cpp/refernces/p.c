#include<stdio.h>
//void f( int*);
void f();
int c=4;
int main()
{
int a=9;
//f(&a);
//f(&a);
f(2);
printf("c:%d\n",c);
}

void f(int a)
{
const int b=5;
static int *p;
p=&c;
++(*p);
printf("%d",*p);
}
/*void f( int *q)
{
static int* p=q;
++(*p);
printf("%d",*p);
}*/
