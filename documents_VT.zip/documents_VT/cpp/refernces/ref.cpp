#include<iostream>
using namespace std;
void inc(int* &i)
{
i++;
}
int main()
{
int *p=0;
cout<<p<<endl;
inc(p);
cout<<p;
}
