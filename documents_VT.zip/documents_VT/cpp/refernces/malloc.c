#include<stdio.h>
#include<stdlib.h>
int main()
{
//int a=9;
int *p=malloc(sizeof(int));
*p=9;
printf("%d\n",*p);
free(p);

int *q=malloc(sizeof(int));
int *t=malloc(sizeof(int));
*p=7;
printf("%d\n",*p);
}
