#include<iostream>
using namespace std;
class A{
int i;
char s;
public:
//A(A &a){}
A(int i){this->i=i;
cout<<&i<<endl;}
A(char s)
{this->s=s;
cout<<static_cast<void*>(&s);}
//cout<<"hi";
};

main()
{
A a(1),b('v');
//cout<<"hi";

}
