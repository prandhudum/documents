#include<iostream>
using namespace std;

int f(int *x)
{
	++(*x);
	return *x;
}

int g(const int &b)
{
//	a++;
	return b;
}
class sam{
	int j;
	int i;
	public:
//	sam()
//{
//cout << "H" <<endl;
//j= 200;
//}
	friend ostream& operator<<(ostream &out,sam &a)
	{
//		out<<a.i;
		out<<a.j;
		return out;
	}

};

sam&  b(sam &s)
{
	return s;
}


int main()
{
	sam s;
	int x=2;
	int y = 5;
//	cout<<f(&x)<<endl;
	cout<<g(1)<<endl;
//	cout<<g(x)<<endl;
	cout<<b(s);
 
}
