
#include<stdlib.h>
#include<iostream>
using namespace std;
int main()
{
int *p;
p=(int*)malloc(20);
*p=1;
cout<<p;

}
