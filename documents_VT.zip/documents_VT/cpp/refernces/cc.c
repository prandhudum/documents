#include<stdio.h>
int main()
{
int x=2;
int *a,*b;
void *c;
a=&x;
printf("a=%d",*a);
c=(int*)a;
printf("c=%d",*c);
b=a;
printf("b=%d",*b);
}
