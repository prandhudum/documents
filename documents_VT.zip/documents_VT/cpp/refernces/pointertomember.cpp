#include <iostream> 
using namespace std;
class Data
{ 
	public:
		int a, b, c; 
		Data(){a=1;}
		void print() const
		{    
			cout << "a =" << a <<" b ="<< b << " c = " << c << endl; 
		} 
};
int main() 
{   Data d, *dp = &d;
	  cout<<dp->a;
	int Data::*pmInt = &Data::a;  
	dp->*pmInt = 47;  
	pmInt = &Data::b;  
	d.*pmInt = 48; 
	pmInt = &Data::c;  
	dp->*pmInt = 49;  
	dp->print();
} 
