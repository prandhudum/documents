
#include <iostream> 
using namespace std; 
class A { 
  int i[100]; 
}; 
class B {
public: 
  void f(); 
}; 
void B::f() {} 
int main() {
A a;
B b; 
  cout << "sizeof struct A = " << sizeof(a) 
       << " bytes" << endl; 
  cout << "sizeof struct B = " << sizeof(b) 
       << " bytes" << endl; 
//  cout << "sizeof CStash in C = "  
  //     << sizeof(CStash) << " bytes" << endl; 
 // cout << "sizeof Stash in C++ = "  
   //    << sizeof(Stash) << " bytes" << endl; 
} //
