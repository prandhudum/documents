#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;
int main()
{
        fstream f1;
	char ch[10]="abcd";
	f1.open("c1");
	int len=strlen(ch);
	for(int i=0;i<len;i++)
	{
            f1.put(ch[i]);
	}
	f1.seekp(2);
        //ifstream fin;
	for(int i=0;i<len;i++)
	{
		f1.get(ch[i]);
		cout<<ch;
	}

}
