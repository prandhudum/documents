












#include<iostream>		
using namespace std;
class A
{
int a;





friend class B;
};
class B
{
int b;
void get(A x)
{
cout<<"a="<<x.a<<endl;

}
};
main()
{
A a1;
B b1;
b1.get(a1);
}



















































