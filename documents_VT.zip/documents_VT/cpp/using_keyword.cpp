#include<iostream>
using namespace std;

class A {
	public:
		int move();
		int turn();
};
class B : private A {
	public:
};
int main()
{
	B b;
	b.move();
	b.turn();
}
