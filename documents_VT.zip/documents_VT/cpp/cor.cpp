#include<iostream>
using namespace std;
static int cnt;
struct st{
	
	float x,y;
	int dis;		
};

int squre(int k)
{
int cnt=0,sq=0,i=k;
while(i > 0)
	{
            if((i & 1) == 1)
	    {
                sq += n << count;
            }

            i = i >> 1;
            count++;
        }

        return sq;
}

st *calculate(st s[],int n,int k,st s2)
{
	int dis;
	k=squre(k);
	static st sam[10];
	int j=0;
	for (int i=0;i<n;i++)
	{
		s[i].dis=((s2.y-s[i].y)*(s2.y-s[i].y))+((s2.x-s[i].x)*(s2.x-s[i].x));
				
		if(s[i].dis==k)
		{
			cnt++;
			sam[j].x=s[i].x;
			sam[j].y=s[i].y;
			j++;
			
		}
	}	
	cout<<"cnt:"<<cnt<<endl;
 return sam;
}

int main()
{
	st s[10],s2;
	st *p;
	int n,k,x,y;
	cout<<"enter x and y:"<<endl;
	cin>>s2.x>>s2.y;	
	cout<<"enter n"<<endl;
	cin>>n;
	cout<<"enter k"<<endl;
	cin>>k;
	for(int i=0;i<n;i++)
	{
	cin>>s[i].x;
	cin>>s[i].y;
	}
	p=calculate(s,n,k,s2);
	for(int i=0;i<cnt;i++)
	{
		cout<<p[i].x;
		cout<<",";
		cout<<p[i].y;
		cout<<" ";
	}
//        cout<<cnt;
}
