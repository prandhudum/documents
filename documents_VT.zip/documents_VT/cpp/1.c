#include<stdio.h>
#include"a.h"
int main()
{
}
