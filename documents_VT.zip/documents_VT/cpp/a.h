#ifndef A_H
#define A_H

#include"1.h"
#include"2.h"


#endif
