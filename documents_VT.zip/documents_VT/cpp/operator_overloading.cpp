#include<iostream>
using namespace std;
class A
{
int a,b;

A operator+(A &a2)
{
A temp;
temp=
}
};

int main()
{
A a1(2),a2(5);
A a3=a1+a2;
}
