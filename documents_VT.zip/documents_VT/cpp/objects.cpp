#include<iostream>
using namespace std;
class A
{
public:
A()
{
cout<<"in A";
}
};
class B
{
};
int main()
{
A a,a1;
B b;
cout<<&a<<endl;
cout<<&b;
}
