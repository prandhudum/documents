#include<iostream>
using namespace std;
class A
{
public:
A(){cout<<"A";}
void f(){cout<<"f";}

};

class B
{
public:
B(){cout<<"B";}
A a;

};

int main()
{
B b;
b.f();
}
