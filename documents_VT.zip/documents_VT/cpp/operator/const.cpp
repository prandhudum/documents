#include<iostream>
using namespace  std;
 int& add(int a,int b)
{
int k;
k=a+b;
int &q=k;

//int *q=&k;
return q;

//return *(a+b);

}

int main()
{
//int j;
// int *p;
int &p=add(2,3);
//++*p;
cout<<(p);

}
