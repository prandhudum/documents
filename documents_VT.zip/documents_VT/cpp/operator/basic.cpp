#include<iostream>
using namespace std;
class A{

	int i;
	public:
	A(){}
	A(int k):i(k){}
	A operator+(A& b){
	
		A temp;
                temp=i+b.i;
		return temp;
	}


        friend ostream& operator<<(ostream &output, A&  b)
	{
         output<<b.i;
	return output;
	
	}

/*        A operator++(int)
	{
		A t;
		t.i=++i;
		return t; 
	}*/
	
	A operator,(A &)
	{
		return *this;
	}

	const A operator ++(int)
	{
		A post;
		post.i=i++;
		return post;
	} 

	A operator++()
	{
//		A t;
//		t.i=i++;
		i++;
//		return t;
	}

        friend istream& operator>>(istream & input,A& b)
	{
		input>>b.i;
		return input;
	}
     
};
int main()
{
	A a(1),b(2),c;
        c=a+b;
	cout<<c;
        c++;
	cout<<c;
	++c;
	cout<<c,++c;
	cout<<"enter no:";
	cin>>c;
	cout<<c;
}
