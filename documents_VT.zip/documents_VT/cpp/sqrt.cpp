#include<iostream>
using namespace std;
#include<math.h>
int main()
{
int a=2;
cout<<sqrt(a);
}
