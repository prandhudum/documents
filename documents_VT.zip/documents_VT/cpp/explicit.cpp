#include<iostream>
using namespace std;
class A
{
     mutable int x;
      mutable int y;
	public:
	A()
	{
		y=6;x=1;
	}
        void get() const
	{
		y++;
		
	}

          void put() const
	{
		x++;
		int *p=new int[10];
		cout<<"p="<<sizeof(int)*10<<"p[0]="<<p[0]<<endl;
		int *s=new int(10);
		cout<<"s="<<sizeof(s)<<"s[0]"<<s[0]<<endl;
		//cin>>p[2];
		p[2]=10;
		cout<<"x="<<x<<"y="<<y<<endl;
	}

};

int main()
{
        A a;
	
	a.get();
	a.put();
}
