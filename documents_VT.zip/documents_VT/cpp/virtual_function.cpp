#include<iostream>
using namespace std;
class A
{
	public:
		virtual void fun() 
		{
			cout<<"in base"<<endl;
		}
};
class B:public A
{
	public:
		void fun() 
		{
			cout<<"in derived"<<endl;
		}
};

int main()
{
	
	B b;
	b.fun();
}
