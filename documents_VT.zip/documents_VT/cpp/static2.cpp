#include<iostream>
using namespace std;
extern int a;
void fun()
{
a=a+1;
cout<<a;
}
