#include<stdio.h>
struct st{
char c;
int i;
void fun();
};

int main()
{
struct st s;
s.fun();
}
