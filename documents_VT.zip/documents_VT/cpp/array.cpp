#include<iostream>
using namespace std;
int main()
{
int n;
cin>>n;
int *p=new int[n];
for(int i=0;i<4;i++)
cin>>p[i];
delete []p;
for(int i=0;i<4;i++)
cout<<p[i]<<endl;
}

