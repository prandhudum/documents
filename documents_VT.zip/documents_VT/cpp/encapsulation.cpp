#include<iostream>
using namespace std;
class A
{
        mutable  int a=1;
	public:
	A(){//a=1;
	}
	 void fun() const 
	{
		a++;
		cout<<"a="<<a<<endl;
	}
};

int main()
{
	A a1;
	a1.fun();
	//cout<<"a="<<a1.a<<endl;
}
