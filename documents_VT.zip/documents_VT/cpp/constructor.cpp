#include<iostream>
using namespace std;
class super
{
private:
 int x=2;
 int y=3;
public:
super()
{
x=4;
//y=5;
cout<<x<<y;
}
};
int main()
{
super s;
}
