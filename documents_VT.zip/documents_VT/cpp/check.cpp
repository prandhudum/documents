#include<iostream>
using namespace std;
#include<math.h>
int main()
{
int a=4;
cout<<sqrt(a);
}
