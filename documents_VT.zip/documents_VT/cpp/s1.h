#ifndef S1_H
#define S1_H
void print(void);
struct st
{
int a;
int b;
};
#endif 
