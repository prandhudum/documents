#include<iostream>
using namespace std;
public class A
{
	int a,b;
	public:
	void get();
};

class B:  public A
{
	public:
		void get()
		{
			cout<<"hi";
		}
};

void A::get()
{
	cin>>a>>b;
	//cout<<a<<b;
}

int main()
{
	A a1;
	a1.get();
	//a1.get();
}
