#include<iostream>
using namespace std;
class A
{
int x;
public:
const  void get( int s) const;
};
const inline void A::get(int s) const
{
s++;
cout<<s;
++s;
cout<<s;
s=s*s;
cout<<s;
}
int main()
{
A a1;
a1.get(2);
}
