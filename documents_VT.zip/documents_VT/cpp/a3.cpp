#include<iostream>
using namespace std;
// const int a=20;
void uday(int a)
{
cout<<"a="<<a<<endl;
cout<<"&a="<<&a<<endl;
}
