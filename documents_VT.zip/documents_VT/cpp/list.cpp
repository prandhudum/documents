#include<list>
#include<iostream>
using namespace std;
int main()
{
int a[]={1,3,4,2,5,6};
list<int> li(a,a+6);
//li.reverse(li.begin(),li.end());
//for(int i=0;i<li.size();i++)
for(int x:a)
cout<<x;
}
