 #include<iostream> 

using namespace std; 
class A
{
//static int a;
public:
void fun()
{
static int a=1;
a=a+1;
cout<<a;
}
};

int main()
{
A a;
a.fun();
a.fun();
}
