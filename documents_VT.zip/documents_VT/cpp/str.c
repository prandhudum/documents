#include<stdio.h>
#pragma pack (1)
struct st
{
char ch;
int a;
//int ap;
char b;
char u;
//double c;
//double e;
};
int main()
{
struct st s;
printf("%d",sizeof(s));
}
