#include<stdio.h>
int main()
{
const volatile int a=50;
printf("%d",a++);

}
