#include<iostream>
using namespace std;
public class A
{
public:
void fun()
{
cout<<"hi";
}
};
int main()
{
A a;
a.fun();
}
