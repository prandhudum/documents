#include<iostream>
using namespace std;
 class A 
{
public:
void get( int p)
{
const int w=p;
cout<<w;
}
};
/*
class C:public A
{
};
*/
int main() 
{ 
	final int i=3;
	
i++;
cout<<i;
   A a;
const int x=1;
int *ptr=(int*)&x;
a.get(1);
} 
