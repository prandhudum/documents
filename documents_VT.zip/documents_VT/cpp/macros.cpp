#include<iostream>
using namespace std;
int sam(int);
#define SAM(a) (((a>5) && (a<5))?(a):5)

int main()
{
int x=5,y=5;
cout<<SAM(++x);
cout<<((x>3)?(x):(x+1));
cout<<x;
cout<<endl;
cout<<sam(++y);
} 

int sam(int a)
{
if(a>5 && a<10)
return a;
else
return 0;
}
