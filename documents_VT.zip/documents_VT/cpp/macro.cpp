#include<iostream>
using namespace std;
#define MAX 10
int main()
{
int num;
num=++MAX;
cout<<num;
return 0;

}
