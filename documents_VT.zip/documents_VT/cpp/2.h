#ifndef _2_H
#define _2_H
struct a{
int data;
char ch;
};

#endif
