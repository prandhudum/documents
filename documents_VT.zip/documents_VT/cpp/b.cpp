#include<iostream>
using namespace std;
extern "C" void sam();

/*class A
{
        int x;
	public:
	A(){x=1;}
		void sam();
};*/

/*int main()
{
	A a;
	a.sam();
}*/
void sam()
{
	//fun();
        cout<<"hi"; 
}
