
#include <iostream>
//#include<stdlib.h>
using namespace std; 
class Test 
{
char e; 
public: 
  
    Test(char c) 
    { 
        e=c; 
        std::cout << "Constructor"<< e<<" executed\n"; 
    } 
    ~Test() 
    { 
        std::cout << "Destructor"<< e<<" executed\n"; 
    }
//     static void fun(); 
}; 
static void fun()
{
cout<<"in fun";
} 

int main() 
{ 
    Test b('b');
    std::cout << "main() starts\n";
    fun(); 
    std::cout << "main() terminates\n"; 
   
} 

