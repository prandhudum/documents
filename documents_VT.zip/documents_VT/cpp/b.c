#include<iostream>
using namespace std;
//#define printText(text) #text 

int main()
{
//        int a=9;
 //       int *p=&a;
//	printf(printTexti((8));
//	printf("\n");
//	return 0;
        cout<<printText(8);
}

