#include<sys/resource.h>
#include<stdio.h>
/*void fun()
{
printf("hii");
}*/
void main()
{
	struct rlimit v;
	if(getrlimit(RLIMIT_STACK,&v)==-1)
		perror("getlimit");
	else
		printf("%u   %u",(unsigned int)v.rlim_cur,(unsigned int)v.rlim_max);
	v.rlim_cur*=3;
	if(setrlimit(RLIMIT_STACK,&v)==-1)
		perror("setrlimit");
//	f();
}
