#include<stdio.h>
#include<sys/sem.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	int id;
	id=semget(11,9,IPC_CREAT|0654);
		if(id<0)
		{
			perror("semget");
			return 0;
		}
	printf("semaphore array created");
}
