
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	pid_t child_pid=fork();
	if(child_pid>0)
		printf("in parent process");
	else if(child_pid==0)
	{
		sleep(30);
		printf("in child process");
	}
}
