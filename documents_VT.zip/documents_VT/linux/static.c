void fun()
{
printf("this is static file");
}
