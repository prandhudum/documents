#include<stdio.h>
#include"static.h"
int main()
{
fun();
}
