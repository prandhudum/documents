#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{

	int p,q;

	if(fork()==0)
	{

		printf("%d %d\n",getpid(),getppid());
		exit(0);
		
	}
	if(fork()==0)
	{
		

		printf("%d %d\n",getpid(),getppid());
		exit(0);
		
	}
	if(fork()>0)
	{
		
		printf("%d %d\n",getpid(),getppid());
		exit(0);
		
	}




}
