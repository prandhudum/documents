from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
image =image.open("/home/dhudupra/Downloads/pics/1.jpeg")
image=np.array(image)
plt.imshow(image)
plt.show()
