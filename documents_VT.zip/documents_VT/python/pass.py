def fun():

sequence = {'p', 'a', 's', 's'}
for val in sequence:
	pass    
