from math import*
print(pi)
