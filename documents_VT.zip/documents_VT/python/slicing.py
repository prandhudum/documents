#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df.head()


# In[9]:


market_df.loc[market_df.Sales>1000]


# In[12]:


market_df.loc[(market_df.Sales == 4233.15), :]


# In[15]:


customers_in_bangalore = ['Cust_1798', 'Cust_1519', 'Cust_637']
market_df.loc[market_df['Cust_id'].isin(customers_in_bangalore), :]


# In[ ]:




