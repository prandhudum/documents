import math
def hello():
	print("hello")
	for step in range(5):     
		 print(step) 
	num=float(input("enter number"))
	math.fabs(num)
	print(num)
	name=input("enter name")
	print("hell",name)
	print (5/2)
	print (-5/2)
	print(type("default string"))
	print(type(b'string with b'))
	for x in range(1,5):
		print(x),
def Main():
	hello()

#if__name__=="main":
#	  main()
if __name__=="__main__": 
    Main() 
