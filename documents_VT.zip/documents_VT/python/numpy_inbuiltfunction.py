#!/usr/bin/env python
# coding: utf-8

# In[27]:


import numpy as np
my_array=np.array([[1,2,3],[6,7,8]])
print(my_array)


# In[34]:


p=set()
print(type(p))
p={()}
print(type(p))
p=()
print(type(p))
p=(())
print(type(p))
p=([])
print(type(p))
p=[]
print(type(p))
p={}
print(type(p))
p=({})
print(type(p))


# In[37]:


np.zeros((2,3,4),dtype=np.int16)


# In[36]:


np.ones((2,3))


# In[41]:


a=np.array(['a'])
print("type:",type(a))
print("dtype:",a.dtype)


# In[42]:


a=np.array([])
print("type:",type(a))
print("dtype:",a.dtype)


# In[46]:


a=np.array([1])
print("type:",type(a))
print("dtype:",a.dtype)


# In[47]:


np.random.random((2,2))


# In[ ]:





# In[ ]:





# In[ ]:




