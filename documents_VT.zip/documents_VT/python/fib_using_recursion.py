def fun(a,b,c,val):
	if c>=val:
		return
	else:
		c=a+b
		print(c)
		a=b
		b=c
		fun(a,b,c,val)
		
num=input("enter number")
val=int(num)
a=0
b=1
c=0
print(a)
print(b)
fun(a,b,c,val)
 
	
