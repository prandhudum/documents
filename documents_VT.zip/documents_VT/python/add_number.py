import keyword
print(keyword.kwlist)

import math as myalise
myalise.cos(myalise.pi)
print(myalise)
'''num1=int(input("enter n"))
fact=1
i=1
for i in range (num1+1):
	fact=fact*i
	print(fact)
	print(i)
print(fact)'''
