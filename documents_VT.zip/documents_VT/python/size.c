#include<stdio.h>
struct h
{
long double x;
char f;
long h;

};
int main()
{
struct h st;
printf("%d",sizeof(st));
}
