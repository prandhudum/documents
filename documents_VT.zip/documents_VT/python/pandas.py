#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np
import pandas as pd
market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df.head()


# In[5]:


market_df.describe()


# In[6]:


market_df.columns


# In[8]:


market_df.shape


# In[9]:


market_df.values


# In[17]:


market_df.set_index("Profit" ,inplace=True)
market_df.head()


# In[44]:


market_df.sort_index(axis=0 ,ascending=False)


# In[40]:


market_df.sort_values(by=['Sales','Order_Quantity'], ascending=True).head(200)


# In[41]:


--help(market_df.sort_values)


# In[42]:


market_df.head()


# In[43]:


market_df.columns


# In[54]:


market_df.set_index('Order_Quantity').head()


# In[ ]:




