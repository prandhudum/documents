def greet(name="pranali",msg="good morning"):
	print("hello,",name+', '+msg)

greet()
