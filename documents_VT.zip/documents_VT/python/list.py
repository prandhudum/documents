list=['a','c','g','h','k','p','i']
print(list[-7:-5])
print(list[2:3])
print(list[2:5])
