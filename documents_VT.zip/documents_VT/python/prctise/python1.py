import sys
i=()
j=[]
print(sys.getsizeof(i),sys.getsizeof(j))
