a=(1,2,3)
a=(7,)



i=()
j=[]
import sys
print(sys.sizeof(i),sys.sizeof(j))






