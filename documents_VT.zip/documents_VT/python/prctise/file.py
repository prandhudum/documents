
f=open("test.txt","r",encoding='utf-8')

print(f.tell())
print(f.seek(0))
"""for line in f:
	print(line,end=' ')"""
f.readline()
#print(f.read(4))
f.close()

