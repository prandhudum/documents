#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df.head()


# In[32]:


print(market_df.iloc[2,3])
print(market_df.loc[2,'Cust_id'])


# In[33]:


print(market_df.iloc[4 , :])
print(market_df.loc[4,:])


# In[10]:


market_df.iloc[4,:]


# In[37]:


print(market_df.iloc[[3,6,7],:])
print(market_df.loc[[3,6,7],:])


# In[19]:


market_df.iloc[3:6,:]


# In[23]:


market_df.iloc[:,3:6].head()


# In[53]:


print(market_df.iloc[3:6,4:7])
print(market_df.loc[3:6,'Ship_id':'Cust_id'])


# In[48]:


#market_df.iloc[[True,False,True,True,False,False,False,True]]
market_df.iloc[[True,False,True,True,False,False,False,True]]


# In[39]:


market_df.set_index('Ord_id').head()


# In[40]:


market_df.head()


# In[50]:


#market_df.loc[[1,3,5],['Cust_id','Sales']]
market_df.loc[[1,3,5],['Cust_id','Sales']]


# In[ ]:




