arr=[1,2,3]
a=[]
for x in arr:
	a.append(arr)
print(a)
