num=int(input("enter a no"))
if num<=1:
	print("no is not a prime")
elif num==2:
	print("no is prime")
else:
	for i in range(3,num+1):
		if num%2==0:
			print("no is not prime")
		elif  num%i==0:
			print("no is not prime")
		else:
			print("no is prime")
 
