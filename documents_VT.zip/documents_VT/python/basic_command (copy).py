#python
'''print"hello"
"""pythigdfytdufdhvj"""
a="""egfryutdefhbvrrrrrrrry"""
print a'''
b=10
if b:
	print "true"
else:
	print"false"
c=30
total="""jdhfyodidngdvg
	dfhvgyfdiug"""
print total
a='word'
print a
c="word"
print c;print b
raw_input("dfdgfuygf")
exit()	
