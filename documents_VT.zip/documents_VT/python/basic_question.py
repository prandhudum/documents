#!/usr/bin/env python
# coding: utf-8

# In[4]:


n=input("enter integer")
list1=[i**2 for i in range(1,5)]
print(list1)


# In[10]:


string=input("enter string")
print(string.split('&'))
s="*"
print(s.join(word[0:] for word in string.split('&')))


# In[11]:


list1=[['SAS','R'],['Tableau','SQL'],['Python','Java']]
print(list1[2][0])


# In[23]:


input_list=['wood', 'old', 'apple', 'big', 'item', 'euphoria']
#print(i for i in input_list if i[0] in 'aeiou')
for word in input_list:
    if word[0] in 'aeiou':
        print(word)


# In[ ]:




