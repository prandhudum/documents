def factorial(val):
	fact=1
	for i in range(1,val+1):
		fact=fact*i
	return fact

num=input("enter number")
val=int(num)
fact=factorial(val)
print("factorial is",fact)
