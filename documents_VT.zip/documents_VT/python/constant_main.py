import constant
print(constant.PI)
print(constant.GRAVITY)
