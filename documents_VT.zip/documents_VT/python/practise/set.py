import sys
#mix={1,1.2,3+4j,'b',1,1,"python"}
mix=(1,2)
print(mix)
print(sys.getsizeof(mix))
