A=[[1,4,5,12],
	[-5,6,9,12],
	[1,6,8,9]]
print(A)
column=[]
for row in A:
	column.append(row[2])
print(column)
