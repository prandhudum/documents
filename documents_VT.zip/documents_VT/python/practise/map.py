my_list = [1, 5, 4, 6, 8, 11, 3, 12]

new_list = set(filter(lambda x: (x%2 == 0) , my_list))

# Output: [4, 6, 8, 12]
print(new_list)
