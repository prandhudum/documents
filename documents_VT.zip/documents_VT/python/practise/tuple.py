mix=(1,1.2,2+3j,'j',"python")
print(mix)
print(type(mix))
#mix[2]=7
print(mix)
print(mix[-4:-1])
