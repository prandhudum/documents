import numpy as np
arr=np.arange(6)
print(arr)
