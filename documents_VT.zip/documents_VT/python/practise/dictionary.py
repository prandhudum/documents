mix={1:'pranali','hi':2,3:'hello'}
mix[1]='komal'
print(mix[1])
