wish="hi pranali"
print(wish[:])
print(wish[::])
print(wish[2::2])
print(wish[:2:1])
print(wish[::1])
print(wish[-5:-1])
print(wish[3::1])

wish1="  hi  pranali  "

print(len(wish1))
x=wish1.strip()
print(len(x))
#print(wish1.lstrip)
#print(wish1.strip)

m=['hiee',' pranali',' how',' are',' u']
#n="@"
N=':'.join(m)
print(N)
