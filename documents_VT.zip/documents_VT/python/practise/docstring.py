def double(num):
	"""double the value"""
	return 2*num

print(double.__doc__)

