d=3
print(isinstance(d,int))
