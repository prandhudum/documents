def m1():
	print("first function")

def m2():
	print("second function")
	m1()

m2()
