def fun(name):
	print("hi ",name," gm")

fun("monica")
