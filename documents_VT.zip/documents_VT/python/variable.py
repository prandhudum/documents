a=b=c=2
print(a)
print(b)
print(c)
