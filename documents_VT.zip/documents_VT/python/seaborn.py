#!/usr/bin/env python
# coding: utf-8

# In[10]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("whitegrid")
market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df.head(40)


# In[34]:


market_df.describe()


# In[71]:


sns.distplot(market_df['Shipping_Cost'],rug=True, rug_kws={"color": "b"},
                  kde_kws={"color": "r", "lw": 2, "label": "KDE"},
                  hist_kws={"histtype": "step", "linewidth": 2,
                            "alpha": 1, "color": "k"})

plt.plot()


# In[60]:


--help(sns.distplot)


# In[77]:


x = np.random.normal(size=1000)
sns.distplot(x);


# In[81]:


sns.jointplot('Sales','Shipping_Cost',market_df)
plt.show()


# In[ ]:




