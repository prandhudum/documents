length=int(input("length of traingle"))
breadth=int(input("breadth of traingle"))
height=int(input("height of a traingle"))
area=length*breadth*height
print(area)

