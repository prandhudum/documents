#!/usr/bin/env python
# coding: utf-8

# In[14]:


import numpy as np
import pandas as pd
data_1=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
data_2=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/cust_dimen.csv")
data_3=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/prod_dimen.csv")
data_4=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/shipping_dimen.csv")
data_5=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/orders_dimen.csv")
data_1.head()


# In[17]:


data_2.head()


# In[19]:


data_3.head()


# In[18]:


data_4.head()


# In[20]:


data_5.head()


# In[12]:


data['Profit'].sum()


# In[22]:


d_1=pd.merge(data_1,data_2,how='inner',on='Cust_id')


# In[25]:


d_2=pd.merge(d_1,data_3,how='inner',on='Prod_id')


# In[26]:


d_3=pd.merge(d_2,data_4,how='inner',on='Ship_id')


# In[27]:


d_4=pd.merge(d_3,data_5,how='inner',on='Ord_id')


# In[28]:


d_4.head()


# In[42]:


group_segment=d_4.groupby('Cust_id')
group_segment.head()


# In[58]:


pd.DataFrame(group_segment['Profit'].sum())


# In[57]:


d_4['is_discount']=d_4['Discount'].apply(lambda x:x>0.04)
d_4.head()


# In[55]:


d_4['Profit']=d_4['Profit'].apply(lambda x:round(x,1))
d_4.head()


# In[ ]:




