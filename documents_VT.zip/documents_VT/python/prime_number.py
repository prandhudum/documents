def primeNo(val):
	if val==2:
		print(i)	
	else:
		for i in range(3,val+1):
			if i%2!=0:
				if val%i!=0:
					print(i)
			
num=int(input("enter number"))
primeNo(num)
