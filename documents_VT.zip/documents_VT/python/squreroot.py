num=int(input("enter a number"))
i=1;
for i in range(1,num):
	
