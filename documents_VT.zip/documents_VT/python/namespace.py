def outer_function():
	global a
	a=10
	def inner_function():
		global a	
		a=20
		print(a)
	inner_function()
	print(a)
a=30
outer_function()
print(a)
