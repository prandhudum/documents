#!/usr/bin/env python
# coding: utf-8

# In[7]:


list=[]
print(list)
list=["pranali"]
print(list)
print(list[0][0])
my_list=[["hi","pranali"],"good morning"]
print(my_list[0])


# In[ ]:




