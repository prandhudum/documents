#!/usr/bin/env python
# coding: utf-8

# In[22]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
x=np.linspace(8,1000)
y=np.linspace(10,1000)
plt.plot(x,y)


# In[13]:


plt.show()


# In[24]:


plt.plot(x,y)
plt.xlabel("x")
plt.ylabel("y")
plt.title("graph")
plt.xlim(20,80)
plt.ylim(200,800)

plt.show()


# In[29]:


x=np.linspace(0,10,10)
y=x*2
plt.plot(x,y,'b+')


# In[36]:


x=np.linspace(0,5,10)
y=np.linspace(3,6,10)

plt.plot(x,y**5,'r-')


# In[44]:


x=np.linspace(1,10)
y=np.log(x)
plt.subplot(121)
plt.plot(x,y)
plt.subplot(1,2,2)
plt.plot(x,y**2)
plt.figure(2)
plt.subplot(121)
plt.plot(x,y**3)


# In[64]:


market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df.head(60)
#market_df.describe()


# In[50]:


plt.boxplot(market_df['Shipping_Cost'])


# In[60]:


plt.hist(market_df['Profit'])
plt.show()


# In[63]:


plt.scatter(market_df['Sales'],market_df['Product_Base_Margin'])
plt.show()


# In[69]:


image = plt.imread("/home/dhudupra/Desktop/images.jpeg")
plt.imshow(image)
plt.show()


# In[70]:


print(type(image))
print(image.shape)
print(image.dtype)


# In[71]:


image


# In[ ]:




