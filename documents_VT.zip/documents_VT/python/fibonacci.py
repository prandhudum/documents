#def main:
number=input("enter number")
a=0
b=1
c=0
val=int(number)
print(a)
print(b)
while c<val:
	c=a+b
	print(c)
	a=b
	b=c
	
		
		
	
	
