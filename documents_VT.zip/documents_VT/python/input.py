def double(num):
	""" double the value"""
	return 2*num
