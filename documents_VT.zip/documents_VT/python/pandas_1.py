#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
market_df=pd.read_csv("/home/dhudupra/Downloads/prep_DataAnalysis_docs/jupyter_notebook_docs/pandas/Introduction to Pandas/global_sales_data/market_fact.csv")
market_df


# In[6]:


market_df[5::2].head(10)


# In[31]:


#print(market_df['Cust_id'])
(type(market_df['Cust_id']))
#print(s)

#print(type(market_df.Cust_id))


# In[33]:


market_df[2]


# In[ ]:




